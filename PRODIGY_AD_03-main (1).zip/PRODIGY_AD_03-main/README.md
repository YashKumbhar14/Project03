# PRODIGY_AD_03
Build a basic stopwatch app that displays minutes, seconds, and milliseconds and allow users to start, pause and reset the timer in flutter
![image](https://github.com/siddhithorat/PRODIGY_AD_03/assets/101985797/b3fdfa34-934a-4a21-b2a0-6a6c32f86db8)
![image](https://github.com/siddhithorat/PRODIGY_AD_03/assets/101985797/aa5fde5e-3924-40db-8705-3049275ef47e)
